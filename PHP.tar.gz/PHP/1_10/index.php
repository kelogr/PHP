<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Exercici10</title>
</head>
<body>
<?php
$dir = "../1_10/Fotos/";
$cont=1;
if(is_dir($dir)){
	if ($dh = opendir($dir)) {
        while (($file = readdir($dh)) !== false) {
            if($cont > 2)
            {
                echo "<a href='imagen".$cont.".php''><img src='".$dir.$file."' width='100px' height='100px'><br>";
            }
            $cont++;
					
        }
        closedir($dh);
    }
}


?>
</body>
</html>