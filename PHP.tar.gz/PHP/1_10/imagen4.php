<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Imagen3</title>
</head>
<body>
<?php
echo "<img src='../1_10/Fotos/2.png'>";		
?>
</body>
</html>