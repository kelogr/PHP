<?php

$i=0; //Será la variable que utilitzarem per saber la quantitat de valor tindrá la nostra array
$numeros;
$result=rand(0,100); //Valor que l'array haurá de buscar
$f_trobat=0; //Un flag que utilitzarem per saber si hem trobar o no el el numero

while ($i<100) { //La nostra array tindrá 100 posicions (del 0 al 99)
	$numeros[$i] = rand(0,100); //a la posició 0 tindrem un numero aleatori

	if($numeros[$i] == $result) //Només entrará quan trobi el numero
	{
		echo "<p>S'ha trobat = ".$numeros[$i]."</p>";
		$i++;
		$f_trobat=1;
	}
	else //Si no ho troba seguirá buscant fins a que s'acabi l'array
	{
		echo "<p>".$numeros[$i]."</p>";
		$i++;
	}
}

if ($f_trobat==0) {
	echo "<p>No s'ha trobat</p>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Exercici8</title>
</head>
<body>
	
</body>
</html>