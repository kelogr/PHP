
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Exercici9</title>
</head>
<body>
<?php
$dir = "../1_9/Fotos/"; //Definim el directori on es troben les fotografies
$cont=1; //Definim aquesta variable per que les dues primeres son archius ocults sense cap format
if(is_dir($dir)){ //Determina si es un directori
	if ($dh = opendir($dir)) { //Devuelve una referencia hacia un recurso externo si lo puede abrir. En el caso que no devolverá un false
        while (($file = readdir($dh)) !== false) { //Mientras encuentre archivos dentro continuará con el bucle
            if($cont > 2)//condición para que entre a partir del tercer archivo
            {
            	echo "<img src='".$dir.$file."'<br>";//$file contiene el nombre del archivo
            }
            $cont++;
					
        }
        closedir($dh); //Cierra el directorio
    }
}

?>
</body>
</html>