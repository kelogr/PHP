
<?php
if(isset($_POST) && !empty($_POST)) //!empty= NO ESTA VACIO 
{
	$opciones = $_POST['opciones']; //Guardamos la opcion que hemos escogido del select del index.php i realizamos la comprovación.
	if ($opciones == 'numero3')
	{
		echo "Tendras que pagar impuestos.";
	}
	else
	{
		echo "No tendras que pagar impuestos";
	}
	

}

?>