<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>1_13</title>
</head>
<body>

<form method="POST" action="ingresos.php">

<p>NOM:<input type="text" name="nom"></p>
<p>Ingresos: <select name="opciones"> 
	<option value="numero1">1-1000</option>
	<option value="numero2">1001-3000</option>
	<option value="numero3">> 3000</option>
</select></p>



<p><input type="submit" name="Inserta"></p>

</form>
    
</body>
</html>