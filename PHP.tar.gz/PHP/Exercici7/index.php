
<?php

	//definim constant

	define('TAM', 10);


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Activitat 7</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<table border="1">
<?php

	$num=1;

	for($mult=10;$num<=TAM;$num++)
	{
		if($num%2==0)
		{
			echo '<tr><td class="par">';
			$result = "<br>".$mult."x".$num."=".$mult*$num."</br>";
			echo $result;
			echo '</td></tr>';	
		}

		else 
		{
			echo '<tr><td class="impar">';
			$result = "<br>".$mult."x".$num."=".$mult*$num."</br>";
			echo $result;
			echo '</td></tr>';	
		}
		
	}

	//Tal i como hicimos en el ejercicio anterior realizaremos un bucle para las operaciones con la diferencia que tendremos que darle un fondo de tabla diferente según si es par o impar. Lo podemos saber haciendo la operacion del numero dividido entre 2 i si el resto es 0 pues es par ($num%2==0), si da algo de resto es impar.

?>
</table>
</body>
</html>