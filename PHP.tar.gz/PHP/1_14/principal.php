<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Principal</title>
</head>
<body>

<a href="insertar.php">Insertar</a>
<a href="ver.php">Listar</a>

<!-- /*submit = subir-enviar al servidor*/ -->

</form>
	
</body>
</html>