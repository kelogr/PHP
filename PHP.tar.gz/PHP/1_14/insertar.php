<?php

//Establir connexio amb base de dades
//Demanen dades com IP del servidor, o nom de host (DNS)
//Nom d'usuari i contrassenya de connexio
//Base de dades a la que ens connectem

	$dbhost='localhost'; //IP DEL SERVIDOR O NOM DNS
	$dbname='klopez_prova';
	$dbuser='klopez_root';
	$dbpassw='linuxlinux';


//obtenim variable de connexio



	$db=new mysqli($dbhost, $dbuser, $dbpassw, $dbname);
	if ($db->connect_errno) //retorna error de connexió
	{
		die('Error de connexió');
	}
	else
	{
		//comprovar $_POST

			if($_POST)
			{
				if($_POST['nom'] && !empty($_POST['nom'])) //!empty= NO ESTA VACIO 
				{

					//es comprova cadascú dels camps i es genera la SQL
					if ($_POST['curs'] == '1SMIX' || $_POST['curs'] == '2SMIX' || $_POST['curs'] == '1DAW' || $_POST['curs'] == '2DAW'){
						$sql="INSERT INTO alumnes(Nom,Cognoms,Curs) VALUES('".$_POST['nom']."','".$_POST['cognom']."','".$_POST['curs']."')";
						echo $sql;
					}
					else {
						die("error de curs");
					}
					//echo $sql;
					
					if(!$result=$db->query($sql)) //si se ha producido de forma incorrecta
					{
						die("error en insert");
					}

				}	

			}

		}

			$db->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Insert</title>
</head>
<body>

<form method="POST" action="<?= $_SERVER['PHP_SELF'];?>">

<p>NOM:<input type="text" name="nom"></p>
<p>COGNOM:<input type="text" name="cognom"></p>
<p>CURS: <input type="text" name="curs"></p>
<p><input type="submit" name="Inserta"></p>

<!-- /*submit = subir-enviar al servidor*/ -->

</form>
	
</body>
</html>