<?php

//Establir connexio amb base de dades
//Demanen dades com IP del servidor, o nom de host (DNS)
//Nom d'usuari i contrassenya de connexio
//Base de dades a la que ens connectem

	$dbhost='localhost'; //IP DEL SERVIDOR O NOM DNS
	$dbname='klopez_prova';
	$dbuser='klopez_root';
	$dbpassw='linuxlinux';


//obtenim variable de connexio



	$db = new mysqli($dbhost,$dbuser, $dbpassw, $dbname);
	
	if ($db->connect_errno) //retorna error de connexió
	{
		die('Error de connexió');
	}

	else
	{
		//comprovar $_POST

	
					$sql="SELECT * from alumnes";
					$result=$db->query($sql);

					
					while($rec=$result->fetch_array())
					{
						echo "<p>".$rec['Nom']." ".$rec['Cognoms']." ".$rec['Curs']."</p>";
					}
					
					
					/*if(!$result=$db->query($sql)) //si se ha producido de forma incorrecta
					{
						die("error en listar");
					}*/

				}	


			$db->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Listar</title>
</head>
<body>

</body>
</html>