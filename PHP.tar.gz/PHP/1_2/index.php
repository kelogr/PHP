<?php

	$num = rand(1,100); //Originarem un numero aleatori entre el 1 i el 100 que la guardarem a una variable

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

<?php
		//Cridem la variable i realitzarem comprovacions per veure si es major o menor al nuemero especificat que donará un resultat
		if($num<50){
			echo 'el número ' .$num. ' es menor de 50';
		}
		else
		{
			echo 'el número ' .$num. ' es mayor de 50';	
		}

?>
	
</body>
</html>