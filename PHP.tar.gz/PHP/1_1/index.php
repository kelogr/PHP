
<?php
	//desem a variable %d el valor de dia de mes
	$d=date('d');

	if($d<=10){ //si el dia es menor o igual a 10 la pagina sortira oberta
		$msg='Oberta';
	}
	else{ //si el dia es major que 10 la pagina sortira tancada
		$msg='Tancada';
	}


?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<?php
		echo 'estat de la pagina : '.$msg; //cridem a la variable msg que segons el dia que sigui tindrá un valor o altre
	?>
	
</body>
</html>