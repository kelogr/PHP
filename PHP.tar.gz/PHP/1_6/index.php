
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

<?php

	$num=1;
	

	for($mult=10;$num<11;$num++)
	{
		$result = "<br>".$mult."x".$num."=".$mult*$num."</br>";
		echo $result;
	}

	//Declaramos num que será la variable que se irá incrementando a medida que se van realizando las operaciones.
	//También tenemos la variable mult que será estatica.
	//$result recogerá el resultado cada vuelta i la imprimirá con el echo

?>
	
</body>
</html>