<?php

$int_integer=123456; //Numero entero.
$dou_doubles=1.23456789; //Numero con decimales.
$boo_boolean=true; //Solo puede ser true or false.
$str_string= "Esto es un string"; //Cadena de caracteres (letras, numeros, decimales, etc...).

//declaramos las variables con una $ delante y las llamamos de la manera que queramos, podemos declarar variables de todo tipo en php sin tener que especificar de que tipo son hasta php3

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

<?php
		echo $int_integer. ' - '; //usando el punto concatenamos. //Imprimirá el valor int.
		
		echo $dou_doubles. ' - '; //Imprimirá el valor con decimales.
		
		echo $boo_boolean. ' - '; //Imprimirá el boolean.
		
		echo $str_string; //Imprimirá la cadena de caracteres.
?>
	
</body>
</html>