<?php

if(isset($_POST) && !empty($_POST)) //!empty= NO ESTA VACIO 
{

    $archivo = fopen("../1_11/dades.txt", "w"); //Abrimos el archivo

    fputs ($archivo, $_POST['nom']); //Escribimos la infomación almacenada en nom enviada per POST
    fputs ($archivo, $_POST['cognom']);
    fputs ($archivo, $_POST['comentari']);

    fclose ($archivo); //Tanquem l'archiu

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>1_11</title>
</head>
<body>

<form method="POST" action="<?= $_SERVER['PHP_SELF'];?>">

<p>NOM:<input type="text" name="nom"></p>
<p>COGNOM:<input type="text" name="cognom"></p>
<p>COMENTARI:<input type="text" name="comentari"></p>
<p><input type="submit" name="Inserta"></p>

<!-- /*submit = subir-enviar al servidor*/ -->

</form>
    
</body>
</html>