<?php

	$aleatori=rand(1,3);

	//creamos una variable con la función rand, que sirve para que saque un valor aleatorio, en este caso entre el uno y el tres.

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	
	<?php

		//Con la utilización de los IF (si se cumple la condición entra dentro) imprimiremos el resultado según cual cumpla

		if($aleatori==1)
		{
			echo "<h1>uno</h1>";
		}

		if($aleatori==2)
		{
			echo "<h1>dos</h1>";
		}

		if($aleatori==3)
		{
			echo "<h1>tres</h1>";
		}

	?>

</body>
</html>