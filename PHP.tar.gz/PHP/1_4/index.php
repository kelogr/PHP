<?php

	$var1=rand(1,100);
	$var2=rand(1,1000);
	$var3=rand(50,100);

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>activitat 4</title>
</head>
<body>

<?php
	echo "Valor1: ".$var1." Valor2: ".$var2." Valor3: ".$var3;

	//Concatenem amb l'utilització de les cometes per als Strings i amb els punts.
?>
	
</body>
</html>