<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>1_12</title>
</head>
<body>

<form method="POST" action="edad.php"> 

<p>NOM:<input type="text" name="nom"></p>
<p>Edad:<input type="text" name="edad"></p>
<p><input type="submit" name="Inserta"></p>

</form>
    
</body>
</html>