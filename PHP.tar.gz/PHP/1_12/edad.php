
<?php
if(isset($_POST) && !empty($_POST)) //l'INFORMACIÓ S'ENVIA A AQUEST ALTRE ARCHIU QUE SERÁ QUI S'ENCARGI DE FILTRAR
{
	$edad = $_POST['edad'];//Guardem el valor edad en una variable
	if ($edad < 18)
	{
		echo "Es menor de edad";
	}
	else
	{
		echo "Es major de edad: ".$edad;
	}
	

}

?>